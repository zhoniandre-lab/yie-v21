# Protokol Chat (biar rapi & tidak pelet)

## Format kerja kita
1. **Satu fase per putaran** — jangan campur redesign + fitur baru + bugfix sekaligus.
2. **Copy-paste block** — setiap file penting diberi path jelas.
3. **Checklist** — selesai = centang di ROADMAP / FIX_NOTES.
4. **Tidak balik ke versi lama** kecuali diminta eksplisit.

## Label pesan
- `PHASE A` API core
- `PHASE B` AI strategy/polish
- `PHASE C` UI engine
- `PHASE D` UI polish visual
- `TEST` hasil uji
- `DEPLOY` instruksi push

## Prioritas tetap
1. Jalan dulu
2. Stabil
3. Cantik
4. Fitur baru
