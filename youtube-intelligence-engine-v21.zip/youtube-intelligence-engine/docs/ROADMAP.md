# ROADMAP — YouTube Intelligence Engine

## v21.0 (SEKARANG) — Full rebuild biar JALAN
- [x] Rewrite API youtube / suggest / ai-*
- [x] Shared IAMHC client (parser + fallback)
- [x] Fix kontrak AI Strategy (payload + schema)
- [x] Fix AI Polish empty success
- [x] index.html v21 + finalDecision + normalizer
- [x] Copy-paste guide

## v21.1 — Stabilisasi
- [ ] Hardening error UI (quota, network, model)
- [ ] Logging ringan (tanpa data sensitif)
- [ ] Test cases otomatis (payload fixtures)
- [ ] Rate-limit guard di client (hemat kuota)

## v21.2 — UI profesional
- [ ] Visual hierarchy dashboard
- [ ] Mobile polish
- [ ] Strategy result cards lebih rapi
- [ ] Empty/loading/skeleton states

## v22 — AI bantu algoritma (terbatas)
- [ ] AI explanation of scores (bukan ganti skor)
- [ ] AI risk narrative from metrics only
- [ ] Optional competitor angle clustering assist

## v23 — Multi-platform (nanti)
- [ ] TikTok / FB / IG modules (terpisah, jangan rusak YouTube core)

## Non-goals (jangan)
- Chatbot bebas
- Klaim “pasti viral”
- AI sebagai otak scoring utama
